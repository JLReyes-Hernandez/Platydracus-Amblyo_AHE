##  RoguePlots 'To run this script copy and paste the .R file into the directory where your files are located'
##  Klopfstein, S., & Spasojevic, T. (2019). Illustrating phylogenetic placement of fossils using RoguePlots: an example from ichneumonid parasitoid wasps (Hymenoptera, Ichneumonidae) and an extensive morphological matrix. PLoS One, 14(4), e0212942.
### To install:
### if(!require(devtools)){install.packages("devtools")}; library(devtools)
### install_github('seraklop/RoguePlots/rogue.plot'); library(rogue.plot)

library(ape)
library(digest)
library(Rcpp)
library(rogue.plot)

#Read the consensus tree
tree = read.nexus('50P_NT_MC_contree2.nex') #tree in nexus format
#tree = read.tree('tree') #tree in pyhlip format

#Read the posterior trees or the bootstrap trees #Open the .ufboot file with Figtree and export all the trees in nexus format
reftrees = read.nexus('50P_NT_MC_ufboot.nex')#tree in nexus format

rogues = 'QH104-C'
#rogues = c('AM0042-L1-S33','AM0043-L1-S14','AM0029-L1-S33','AM0102-L1-S44','AM0044-L1-S34','AM0101-L1-S8') #name of the rogue or a clade c('NAME1','NAME2')

create.rogue.plot(tree, reftrees,rogues,  outgroup = c('sc_02_S39','ENT130_L1_S4'), type = 'Spectral', col = NULL,
                  outfile.table = 'table.txt', outfile.plot = 'graph.pdf', min.prob = 0.01, cex.tips = par('cex'), tip.color = 'black')
